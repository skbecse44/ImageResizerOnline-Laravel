<!DOCTYPE html>
<html>

<head>








    <?php if(isset($index)): ?>


    <title>Image Resizer Online - Resize Images Online Without Losing Quality</title>

    <meta name="keywords" content="online image resizer, free image resizer, resize pictures, resize photos, reduce photo size, reduce picture size" />

    <meta name="description" content="Image Resizer Online is free, online and powerful image resizer. Resize your images, photos, scanned documents without losing quality and in a easy way!" />

<?php endif; ?>


<?php if(isset($image_optimizer)): ?>

<title>Image Optimizer Online - Optimize Images Online as ease</title>

<meta name="keywords" content="online optimizer, free image optimizer, optimize pictures, optimize photos, increase photo size, increase picture size" />

<meta name="description" content="Image Optimizer Online is free, online and powerful image optimizer. optimize your images, photos, scanned documents in a easy way!" />

<?php endif; ?>



<?php if(isset($image_converter)): ?>

<title>Image Converter Online - Convert Images Online as ease</title>

<meta name="keywords" content="online converter, free image converter, convert pictures, convert photos, convert photo size" />

<meta name="description" content="Image Converter Online is free, online and powerful image converter. convert your images, photos, scanned documents in a easy way to jpg, png, webp, gif format and so on!" />

<?php endif; ?>




<?php if(isset($image_compressor)): ?>

<title>Image Compressor Online - Compress Images Online Without Losing Quality</title>

<meta name="keywords" content="online compressor, free image compressor, compress pictures, compress photos, compress photo size, compress picture size" />

<meta name="description" content="Image Compressor Online is free, online and powerful image compressor. Compress your images, photos, scanned documents in a easy way!" />

<?php endif; ?>




<?php if(isset($image_compressor_under20kb)): ?>

<title>Image Compressor Under20KB Online - Compress Images Online Under20KB Without Losing Quality</title>

<meta name="keywords" content="online compressor under20kb, free image compressor under20kb, compress pictures under20kb, compress photos under20kb, compress photo size under20kb, compress picture size under20kb" />

<meta name="description" content="Image Compressor Under20KB Online is free, online and powerful image compressor. Compress your images, photos, scanned documents Under20KB in a easy way!" />

<?php endif; ?>


<?php if(isset($image_compressor_under30kb)): ?>

<title>Image Compressor Under30KB Online -
    Compress Images Online Under30KB Without Losing Quality</title>

<meta name="keywords" content="online compressor under30kb,
 free image compressor under30kb,
  compress pictures under30kb,
  compress photos under30kb,
   compress photo size under30kb,
 compress picture size under30kb" />

<meta name="description" content="Image Compressor
Under30KB Online is free, online and powerful image compressor.
Compress your images, photos, scanned documents in a easy way!" />

<?php endif; ?>



<?php if(isset($image_compressor_under40kb)): ?>

<title>Image Compressor Under40KB Online -
    Compress Images Online Under40KB Without Losing Quality</title>

<meta name="keywords" content="online compressor under40kb,
 free image compressor under40kb,
  compress pictures under40kb,
  compress photos under40kb,
   compress photo size under40kb,
 compress picture size under40kb" />

<meta name="description" content="Image Compressor
Under40KB Online is free, online and powerful image compressor.
Compress your images, photos, scanned documents in a easy way!" />

<?php endif; ?>




<?php if(isset($image_compressor_under50kb)): ?>

<title>Image Compressor Under50KB Online -
    Compress Images Online Under50KB Without Losing Quality</title>

<meta name="keywords" content="online compressor under50kb,
 free image compressor under50kb,
  compress pictures under50kb,
  compress photos under50kb,
   compress photo size under50kb,
 compress picture size under50kb" />

<meta name="description" content="Image Compressor
Under50KB Online is free, online and powerful image compressor.
Compress your images, photos, scanned documents in a easy way!" />

<?php endif; ?>




<?php if(isset($image_compressor_under60kb)): ?>

<title>Image Compressor Under60KB Online -
    Compress Images Online Under60KB Without Losing Quality</title>

<meta name="keywords" content="online compressor under60kb,
 free image compressor under60kb,
  compress pictures under60kb,
  compress photos under60kb,
   compress photo size under60kb,
 compress picture size under60kb" />

<meta name="description" content="Image Compressor
Under60KB Online is free, online and powerful image compressor.
Compress your images, photos, scanned documents in a easy way!" />

<?php endif; ?>





<?php if(isset($image_compressor_under80kb)): ?>

<title>Image Compressor Under80KB Online -
    Compress Images Online Under80KB Without Losing Quality</title>

<meta name="keywords" content="online compressor under80kb,
 free image compressor under80kb,
  compress pictures under80kb,
  compress photos under80kb,
   compress photo size under80kb,
 compress picture size under80kb" />

<meta name="description" content="Image Compressor
Under80KB Online is free, online and powerful image compressor.
Compress your images, photos, scanned documents in a easy way!" />

<?php endif; ?>




<?php if(isset($image_compressor_under100kb)): ?>

<title>Image Compressor Under100KB Online -
    Compress Images Online Under100KB Without Losing Quality</title>

<meta name="keywords" content="online compressor under100kb,
 free image compressor under100kb,
  compress pictures under100kb,
  compress photos under100kb,
   compress photo size under100kb,
 compress picture size under100kb" />

<meta name="description" content="Image Compressor
Under100KB Online is free, online and powerful image compressor.
Compress your images, photos, scanned documents in a easy way!" />

<?php endif; ?>



<?php if(isset($image_compressor_under150kb)): ?>

<title>Image Compressor Under150KB Online -
    Compress Images Online Under150KB Without Losing Quality</title>

<meta name="keywords" content="online compressor under150kb,
 free image compressor under150kb,
  compress pictures under150kb,
  compress photos under150kb,
   compress photo size under150kb,
 compress picture size under150kb" />

<meta name="description" content="Image Compressor
Under150KB Online is free, online and powerful image compressor.
Compress your images, photos, scanned documents in a easy way!" />

<?php endif; ?>



<?php if(isset($image_compressor_under200kb)): ?>

<title>Image Compressor Under200KB Online -
    Compress Images Online Under200KB Without Losing Quality</title>

<meta name="keywords" content="online compressor under200kb,
 free image compressor under200kb,
  compress pictures under200kb,
  compress photos under200kb,
   compress photo size under200kb,
 compress picture size under200kb" />

<meta name="description" content="Image Compressor
Under200KB Online is free, online and powerful image compressor.
Compress your images, photos, scanned documents in a easy way!" />

<?php endif; ?>




<?php if(isset($image_compressor_under300kb)): ?>

<title>Image Compressor Under300KB Online -
    Compress Images Online Under300KB Without Losing Quality</title>

<meta name="keywords" content="online compressor under300kb,
 free image compressor under300kb,
  compress pictures under300kb,
  compress photos under300kb,
   compress photo size under300kb,
 compress picture size under300kb" />

<meta name="description" content="Image Compressor
Under300KB Online is free, online and powerful image compressor.
Compress your images, photos, scanned documents in a easy way!" />

<?php endif; ?>




<?php if(isset($image_compressor_under500kb)): ?>

<title>Image Compressor Under500KB Online -
    Compress Images Online Under500KB Without Losing Quality</title>

<meta name="keywords" content="online compressor under500kb,
 free image compressor under500kb,
  compress pictures under500kb,
  compress photos under500kb,
   compress photo size under500kb,
 compress picture size under500kb" />

<meta name="description" content="Image Compressor
Under500KB Online is free, online and powerful image compressor.
Compress your images, photos, scanned documents in a easy way!" />

<?php endif; ?>





<?php if(isset($image_compressor_under1024kb)): ?>

<title>Image Compressor Under1MB Online -
    Compress Images Online Under1MB Without Losing Quality</title>

<meta name="keywords" content="online compressor under1mb,
 free image compressor under1mb,
  compress pictures under1mb,
  compress photos under1mb,
   compress photo size under1mb,
 compress picture size under1mb" />

<meta name="description" content="Image Compressor
Under1mb Online is free, online and powerful image compressor.
Compress your images, photos, scanned documents in a easy way!" />

<?php endif; ?>



<?php if(isset($image_compressor_under2048kb)): ?>

<title>Image Compressor Under2MB Online -
    Compress Images Online Under2MB Without Losing Quality</title>

<meta name="keywords" content="online compressor under2mb,
 free image compressor under2mb,
  compress pictures under2mb,
  compress photos unde2mb,
   compress photo size under2mb,
 compress picture size under2mb" />

<meta name="description" content="Image Compressor
Under2mb Online is free, online and powerful image compressor.
Compress your images, photos, scanned documents in a easy way!" />

<?php endif; ?>



<?php if(isset($image_webpmaker)): ?>

<title>WebP Maker Online -
    Convert Images to WebP Format</title>

<meta name="keywords" content="online converter webp,
 free image converter webp,
  convert pictures webp,
  convert photos webp,
   convert photo size webp,
 convert picture size webp" />

<meta name="description" content="Image Converter
WebP Online is free, online and powerful image converter.
Convert your images, photos, scanned documents to webp in a easy way!" />

<?php endif; ?>





<?php if(isset($image_webptopng)): ?>

<title>WebP to PNG Online -
    Convert Images to WebP to PNG Format</title>

<meta name="keywords" content="online converter webp to png,
 free image converter webp to png,
  convert pictures webp to png,
  convert photos webp to png,
   convert photo size webp to png,
 convert picture size webp to png" />

<meta name="description" content="Image Converter
WebP to PNG Online is free, online and powerful image converter.
Convert your images, photos, scanned documents to webp to png in a easy way!" />

<?php endif; ?>




<?php if(isset($image_webptojpg)): ?>

<title>WebP to JPG Online -
    Convert Images to WebP to JPG Format</title>

<meta name="keywords" content="online converter webp to jpg,
 free image converter webp to jpg,
  convert pictures webp to jpg,
  convert photos webp to jpg,
   convert photo size webp to jpg,
 convert picture size webp to jpg" />

<meta name="description" content="Image Converter
WebP to JPG Online is free, online and powerful image converter.
Convert your images, photos, scanned documents to webp to jpg in a easy way!" />

<?php endif; ?>


<?php if(isset($image_webptogif)): ?>

<title>WebP to GIF Online -
    Convert Images to WebP to GIF Format</title>

<meta name="keywords" content="online converter webp to gif,
 free image converter webp to gif,
  convert pictures webp to gif,
  convert photos webp to gif,
   convert photo size webp to gif,
 convert picture size webp to gif" />

<meta name="description" content="Image Converter
WebP to GIF Online is free, online and powerful image converter.
Convert your images, photos, scanned documents to webp to gif in a easy way!" />

<?php endif; ?>











<?php if(isset($image_pngmaker)): ?>

<title>PNG Maker Online -
    Convert Images to WebP Format</title>

<meta name="keywords" content="online converter png,
 free image converter png,
  convert pictures png,
  convert photos png,
   convert photo size png,
 convert picture size png" />

<meta name="description" content="Image Converter
png Online is free, online and powerful image converter.
Convert your images, photos, scanned documents to png in a easy way!" />

<?php endif; ?>





<?php if(isset($image_pngtowebp)): ?>

<title>PNG to WebP Online -
    Convert Images to PNG to WebP Format</title>

<meta name="keywords" content="online converter png to webp,
 free image converter png to webp,
  convert pictures png to webp,
  convert photos png to webp,
   convert photo size png to webp,
 convert picture size png to webp" />

<meta name="description" content="Image Converter
png to webp Online is free, online and powerful image converter.
Convert your images, photos, scanned documents to png to webp in a easy way!" />

<?php endif; ?>




<?php if(isset($image_pngtojpg)): ?>

<title>PNG to JPG Online -
    Convert Images to WebP to JPG Format</title>

<meta name="keywords" content="online converter png to jpg,
 free image converter webp to jpg,
  convert pictures png to jpg,
  convert photos png to jpg,
   convert photo size png to jpg,
 convert picture size png to jpg" />

<meta name="description" content="Image Converter
png to JPG Online is free, online and powerful image converter.
Convert your images, photos, scanned documents to png to jpg in a easy way!" />

<?php endif; ?>


<?php if(isset($image_pngtogif)): ?>

<title>PNG to GIF Online -
    Convert Images to WebP to GIF Format</title>

<meta name="keywords" content="online converter png to gif,
 free image converter png to gif,
  convert pictures png to gif,
  convert photos png to gif,
   convert photo size png to gif,
 convert picture size png to gif" />

<meta name="description" content="Image Converter
PNG to GIF Online is free, online and powerful image converter.
Convert your images, photos, scanned documents to png to gif in a easy way!" />

<?php endif; ?>





<?php if(isset($image_jpgmaker)): ?>

<title>JPG or JPEG Maker Online -
    Convert Images to WebP Format</title>

<meta name="keywords" content="online converter jpg,
 free image converter jpg,
  convert pictures jpg,
  convert photos jpg,
   convert photo size jpg,
 convert picture size jpg" />

<meta name="description" content="Image Converter
jpg Online is free, online and powerful image converter.
Convert your images, photos, scanned documents to jpg in a easy way!" />

<?php endif; ?>





<?php if(isset($image_jpgtopng)): ?>

<title>JPG to PNG Online -
    Convert Images to WebP to PNG Format</title>

<meta name="keywords" content="online converter jpg to png,
 free image converter jpg to png,
  convert pictures jpg to png,
  convert photos jpg to png,
   convert photo size jpg to png,
 convert picture size jpg to png" />

<meta name="description" content="Image Converter
JPG to PNG Online is free, online and powerful image converter.
Convert your images, photos, scanned documents to jpg to png in a easy way!" />

<?php endif; ?>




<?php if(isset($image_jpgtowebp)): ?>

<title>JPG or JPEG to WebP Online -
    Convert Images to WebP to JPG Format</title>

<meta name="keywords" content="online converter jpg to webp,
 free image converter jpg to wbep,
  convert pictures jpg to webp,
  convert photos jpg to webp,
   convert photo size jpg to webp,
 convert picture size jpg to webp" />

<meta name="description" content="Image Converter
JPG to WebP Online is free, online and powerful image converter.
Convert your images, photos, scanned documents to jpg to webp in a easy way!" />

<?php endif; ?>


<?php if(isset($image_jpgtogif)): ?>

<title>JPG or JPEG to GIF Online -
    Convert Images to WebP to GIF Format</title>

<meta name="keywords" content="online converter jpg to gif,
 free image converter jpg to gif,
  convert pictures jpg to gif,
  convert photos jpg to gif,
   convert photo size jpg to gif,
 convert picture size jpg to gif" />

<meta name="description" content="Image Converter
JPG to GIF Online is free, online and powerful image converter.
Convert your images, photos, scanned documents to webp to gif in a easy way!" />

<?php endif; ?>














<base href="http://localhost">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-190299143-2"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-190299143-2');
</script>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

<link rel="apple-touch-icon" sizes="57x57" href="/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
<link rel="manifest" href="/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">



<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>




    <style>

        *, *::before, *::after {
            margin: 0;
            padding: 0;
            box-sizing: border-box;

            font: 14px/1.42 'Open Sans', sans-serif;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "Roboto", "Oxygen", "Ubuntu", "Cantarell", "Fira Sans", "Droid Sans", "Helvetica Neue", Arial, sans-serif;

            color: #111;
        }

        h1{
            font-weight: 400;
            font-size: 1.8em;
        }


        h3{
            font-weight: 400;
            font-size: 1.4em;
        }


        main {

            width: 80%;
            margin: 8px auto;
            padding: 24px;
            border: 1px solid #EFEFEE;
        }

        #main-nav ul {
            display: block;
            background-color: #EFEFEE;
            list-style-type: none;
            margin-top:8px;
            margin-bottom:0;
            padding-top: 1px;

        }

        #main-nav ul li {
            border-right: 1px solid silver;
            display: inline-block;
            padding: 12px 8px;


        }

        #main-nav ul li a {
            color: black;
            text-decoration: none;
        }


        #main-nav ul li a:hover {
            text-decoration: underline;
        }



        #sub-menu ul {
            display: block;
            background-color: #EFEFEE;
            list-style-type: none;

            padding-top: 1px;
            margin-top:2px;

        }

        #sub-menu ul li {
            border-right: 1px solid silver;
            display: inline-block;
            padding: 12px 8px;


        }

        #sub-menu ul li a {
            color: black;
            text-decoration: none;
        }


        #sub-menu ul li a:hover {
            text-decoration: underline;
        }


        /* Style the tab */
        .tab {
            overflow: hidden;
            border: 1px solid #ccc;
            background-color: #f1f1f1;
        }

        /* Style the buttons inside the tab */
        .tab button {
            background-color: inherit;
            float: left;
            border: none;
            outline: none;
            cursor: pointer;
            padding: 14px 16px;
            transition: 0.3s;
            font-size: 17px;
        }

        /* Change background color of buttons on hover */
        .tab button:hover {
            background-color: #ddd;
        }

        /* Create an active/current tablink class */
        .tab button.active {
            background-color: #ccc;
        }

        /* Style the tab content */
        .tabcontent {
            display: none;
            padding: 6px 12px;
            border: 1px solid #ccc;
            border-top: none;
        }


        .left-panel{

            float: left;

width: 240px;
        }



        .right-panel{
            margin-left: 240px;

        }


#header-logo{
    float: left;
}

#like-share-wrapper{
    padding: 8px 0;

float:right;
display:inline-block;


}
        @media  only screen and (max-width: 600px) {




            #header-logo{
    float: none;
    display: block;
}

#like-share-wrapper{
    padding: 8px;

float:none;
display:inline-block;




}


            main {

width: 100%;
margin: 0;
padding: 4px;
border: 1px solid #EFEFEE;
}



            .left-panel{



width: 100%;

float: none;
}



.right-panel{
margin-left: 0;

}


        }

    </style>
</head>

<body>





    <div id="fb-root"></div>
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v10.0" nonce="LovkzHvT"></script>




<div id="root-con">

    <main>

        <header style="overflow:hidden;


        ">


            <img


            id="header-logo"
            src="assets/logo.jpg"

            alt="Image Resizer Online"



            width="100%"

        style="
        max-width:320px;
        "



            />




<div

id="like-share-wrapper">

<p style="margin:8px 0">
Like & Share
</p>
<iframe src="https://www.facebook.com/plugins/like.php?href=https%3A%2F%2Fwww.imageresizeronline.com%2F&width=150&layout=button_count&action=like&size=small&share=true&height=46&appId" width="150" height="46" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowfullscreen="true" allow="autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share"></iframe>

</div>
        </header>

        <nav>
            <div id="main-nav">

                <ul>
                    <li><a href="/">Image Resizer</a>
                        <li><a href="image-optimizer">Image Optimizer</a>
                            <li><a href="image-compressor">Image Compressor</a>
                                <li><a href="image-converter">Image Converter</a>
                                    <li><a href="image-converter/webp-maker">WebP</a>
                                        <li><a href="image-converter/png-maker">PNG</a>
                                            <li><a href="image-converter/jpg-maker">JPG</a>


                </ul>
            </div>


            <div id="sub-menu">





                <?php if(
                                    isset($image_pngmaker)||

                isset($image_pngtojpg)||


                isset($image_pngtojpg_upload)||

                isset($image_pngtojpg_download)||


                isset($image_pngtogif)||


isset($image_pngtogif_upload)||

isset($image_pngtogif_download)||





isset($image_pngtowebp)||


isset($image_pngtowebp_upload)||

isset($image_pngtowebp_download) ): ?>


<ul>
    <li><a href="image-converter/png-maker">Make PNG</a>
        <li><a href="image-converter/png-to-jpg">PNG to JPG</a>
            <li><a href="image-converter/png-to-webp">PNG to WebP</a>
                <li><a href="image-converter/png-to-gif">PNG to GIF</a>

    </ul>

                <?php endif; ?>








                <?php if(

                    isset($image_jpgmaker)||
                isset($image_jpgtopng)||


                isset($image_jpgtopng_upload)||

                isset($image_jpgtopng_download)||


                isset($image_jpgtogif)||


isset($image_jpgtogif_upload)||

isset($image_jpgtogif_download)||





isset($image_jpgtowebp)||


isset($image_jpgtowebp_upload)||

isset($image_jpgtowebp_download) ): ?>


<ul>
    <li><a href="image-converter/jpg-maker">Make JPG</a>
        <li><a href="image-converter/jpg-to-png">JPG to PNG</a>
            <li><a href="image-converter/jpg-to-webp">JPG to WebP</a>
                <li><a href="image-converter/jpg-to-gif">JPG to GIF</a>

    </ul>

                <?php endif; ?>






                <?php if(

isset($image_webpmaker)||


                isset($image_webptopng)||


                isset($image_webptopng_upload)||

                isset($image_webptopng_download)||


                isset($image_webptojpg)||


                isset($image_webptojpg_upload)||

                isset($image_webptojpg_download)||

                isset($image_webptogif)||


                isset($image_webptogif_upload)||

                isset($image_webptogif_download)

                ): ?>



<ul>
    <li><a href="image-converter/webp-maker">Make WebP</a>
        <li><a href="image-converter/webp-to-png">WebP to PNG</a>
            <li><a href="image-converter/webp-to-jpg">WebP to JPG</a>
                <li><a href="image-converter/webp-to-gif">WebP to GIF</a>

    </ul>

                <?php endif; ?>



                <?php if(


                isset($image_compressor_under20kb)||
                isset($image_compressor_under30kb)||

                isset($image_compressor_under40kb)||
                isset($image_compressor_under50kb)||


                isset($image_compressor_under60kb)||

                isset($image_compressor_under80kb)||

                isset($image_compressor_under100kb)||

                isset($image_compressor_under150kb)||

                isset($image_compressor_under200kb)||

                isset($image_compressor_under300kb)||
                isset($image_compressor_under500kb)||
                isset($image_compressor_under1024kb)||
                isset($image_compressor_under2048kb)||

                isset($image_compressor)||


                isset($image_compressor_upload) || isset($image_compressor_download) ): ?>



                <ul>
                    <li><a href="image-compressor">Image Compressor</a>
                        <li><a href="image-compressor/under20kb">Compress Image Under 20KB</a>

                            <li><a href="image-compressor/under30kb">Compress Image Under 30KB</a>
                                <li><a href="image-compressor/under40kb">Compress Image Under 40KB</a>
                                    <li><a href="image-compressor/under50kb">Compress Image Under 50KB</a>

                                    <li><a href="image-compressor/under60kb">Compress Image Under 60KB</a>
                                        <li><a href="image-compressor/under80kb">Compress Image Under 80KB</a>
                                            <li><a href="image-compressor/under100kb">Compress Image Under 100KB</a>

                                            <li><a href="image-compressor/under150kb">Compress Image Under 150KB</a>
                                                <li><a href="image-compressor/under200kb">Compress Image Under 200KB</a>
                                                    <li><a href="image-compressor/under300kb">Compress Image Under 300KB</a>
                                                        <li><a href="image-compressor/under500kb">Compress Image Under 500KB</a>
                                                            <li><a href="image-compressor/under1mb">Compress Image Under 1MB</a>
                                                                <li><a href="image-compressor/under2mb">Compress Image Under 2mb</a>

                </ul>
                <?php endif; ?>
            </div>

        </nav>


        <div id="main-con" style="padding:8px 4px;">


            <div


            class="left-panel"



>


            </div>

            <div

            class="right-panel"
            >


                <?php if(isset($error_message)): ?>

                    <div style="
padding: 24px 16px;
border-radius: 4px;
background-color: red;
margin: 8px 0;

">

                        <h1 style="color: white;">

                            <?php echo e($error_message); ?>

                        </h1>
                    </div>

                 <?php endif; ?>



                    <?php if(isset($index)): ?>
                        <?php echo $__env->yieldContent('image-resizer'); ?>
                    <?php endif; ?>

                    <?php if(isset($image_resizer_upload)): ?>
                        <?php echo $__env->yieldContent('image-resizer-upload'); ?>

                    <?php endif; ?>


                    <?php if(isset($image_resizer_download)): ?>
                    <?php echo $__env->yieldContent('image-resizer-download'); ?>

                     <?php endif; ?>




                    <?php if(isset($image_converter)): ?>
                    <?php echo $__env->yieldContent('image-converter'); ?>
                <?php endif; ?>




                    <?php if(isset($image_compressor)): ?>
                    <?php echo $__env->yieldContent('image-compressor'); ?>
                <?php endif; ?>

                <?php if(isset($image_compressor_upload)): ?>
                    <?php echo $__env->yieldContent('image-compressor-upload'); ?>

                <?php endif; ?>


                <?php if(isset($image_compressor_download)): ?>
                <?php echo $__env->yieldContent('image-compressor-download'); ?>

                 <?php endif; ?>



                 <?php if(isset($image_compressor_under20kb)): ?>
                 <?php echo $__env->yieldContent('under20kb'); ?>
             <?php endif; ?>

             <?php if(isset($image_compressor_under20kb_upload)): ?>
                 <?php echo $__env->yieldContent('under20kb-upload'); ?>

             <?php endif; ?>


             <?php if(isset($image_compressor_under20kb_download)): ?>

             <?php echo $__env->yieldContent('under20kb-download'); ?>

              <?php endif; ?>





              <?php if(isset($image_compressor_under30kb)): ?>
              <?php echo $__env->yieldContent('under30kb'); ?>
          <?php endif; ?>

          <?php if(isset($image_compressor_under30kb_upload)): ?>
              <?php echo $__env->yieldContent('under30kb-upload'); ?>

          <?php endif; ?>


          <?php if(isset($image_compressor_under30kb_download)): ?>

          <?php echo $__env->yieldContent('under30kb-download'); ?>

           <?php endif; ?>





           <?php if(isset($image_compressor_under50kb)): ?>
           <?php echo $__env->yieldContent('under50kb'); ?>
       <?php endif; ?>

       <?php if(isset($image_compressor_under50kb_upload)): ?>
           <?php echo $__env->yieldContent('under50kb-upload'); ?>

       <?php endif; ?>


       <?php if(isset($image_compressor_under50kb_download)): ?>

       <?php echo $__env->yieldContent('under50kb-download'); ?>

        <?php endif; ?>






        <?php if(isset($image_compressor_under60kb)): ?>
        <?php echo $__env->yieldContent('under60kb'); ?>
    <?php endif; ?>

    <?php if(isset($image_compressor_under60kb_upload)): ?>
        <?php echo $__env->yieldContent('under60kb-upload'); ?>

    <?php endif; ?>


    <?php if(isset($image_compressor_under60kb_download)): ?>

    <?php echo $__env->yieldContent('under60kb-download'); ?>

     <?php endif; ?>




     <?php if(isset($image_compressor_under1024kb)): ?>
     <?php echo $__env->yieldContent('under1024kb'); ?>
 <?php endif; ?>

 <?php if(isset($image_compressor_under1024kb_upload)): ?>
     <?php echo $__env->yieldContent('under1024kb-upload'); ?>

 <?php endif; ?>


 <?php if(isset($image_compressor_under1024kb_download)): ?>

 <?php echo $__env->yieldContent('under1024kb-download'); ?>

  <?php endif; ?>



  <?php if(isset($image_compressor_under2048kb)): ?>
  <?php echo $__env->yieldContent('under2048kb'); ?>
<?php endif; ?>

<?php if(isset($image_compressor_under2048kb_upload)): ?>
<
  <?php echo $__env->yieldContent('under2048kb-upload'); ?>

<?php endif; ?>


<?php if(isset($image_compressor_under2048kb_download)): ?>

<?php echo $__env->yieldContent('under2048kb-download'); ?>

<?php endif; ?>










     <?php if(isset($image_compressor_under80kb)): ?>
     <?php echo $__env->yieldContent('under80kb'); ?>
 <?php endif; ?>

 <?php if(isset($image_compressor_under80kb_upload)): ?>
     <?php echo $__env->yieldContent('under80kb-upload'); ?>

 <?php endif; ?>


 <?php if(isset($image_compressor_under80kb_download)): ?>

 <?php echo $__env->yieldContent('under80kb-download'); ?>

  <?php endif; ?>






        <?php if(isset($image_compressor_under100kb)): ?>
        <?php echo $__env->yieldContent('under100kb'); ?>
    <?php endif; ?>

    <?php if(isset($image_compressor_under100kb_upload)): ?>
        <?php echo $__env->yieldContent('under100kb-upload'); ?>

    <?php endif; ?>


    <?php if(isset($image_compressor_under100kb_download)): ?>

    <?php echo $__env->yieldContent('under100kb-download'); ?>

     <?php endif; ?>






     <?php if(isset($image_compressor_under200kb)): ?>
     <?php echo $__env->yieldContent('under200kb'); ?>
 <?php endif; ?>

 <?php if(isset($image_compressor_under200kb_upload)): ?>
     <?php echo $__env->yieldContent('under200kb-upload'); ?>

 <?php endif; ?>


 <?php if(isset($image_compressor_under200kb_download)): ?>

 <?php echo $__env->yieldContent('under200kb-download'); ?>

  <?php endif; ?>


  <?php if(isset($image_compressor_under300kb)): ?>
  <?php echo $__env->yieldContent('under300kb'); ?>
<?php endif; ?>

<?php if(isset($image_compressor_under300kb_upload)): ?>
  <?php echo $__env->yieldContent('under300kb-upload'); ?>

<?php endif; ?>


<?php if(isset($image_compressor_under300kb_download)): ?>

<?php echo $__env->yieldContent('under300kb-download'); ?>

<?php endif; ?>



<?php if(isset($image_compressor_under500kb)): ?>
<?php echo $__env->yieldContent('under500kb'); ?>
<?php endif; ?>

<?php if(isset($image_compressor_under500kb_upload)): ?>
<?php echo $__env->yieldContent('under500kb-upload'); ?>

<?php endif; ?>


<?php if(isset($image_compressor_under500kb_download)): ?>

<?php echo $__env->yieldContent('under500kb-download'); ?>

<?php endif; ?>




<?php if(isset($image_compressor_under40kb)): ?>
<?php echo $__env->yieldContent('under40kb'); ?>
<?php endif; ?>

<?php if(isset($image_compressor_under40kb_upload)): ?>
<?php echo $__env->yieldContent('under40kb-upload'); ?>

<?php endif; ?>


<?php if(isset($image_compressor_under40kb_download)): ?>

<?php echo $__env->yieldContent('under40kb-download'); ?>

<?php endif; ?>



<?php if(isset($image_compressor_under150kb)): ?>
<?php echo $__env->yieldContent('under150kb'); ?>
<?php endif; ?>

<?php if(isset($image_compressor_under150kb_upload)): ?>
<?php echo $__env->yieldContent('under150kb-upload'); ?>

<?php endif; ?>


<?php if(isset($image_compressor_under150kb_download)): ?>

<?php echo $__env->yieldContent('under150kb-download'); ?>

<?php endif; ?>













                    <?php if(isset($image_optimizer)): ?>
                        <?php echo $__env->yieldContent('image-optimizer'); ?>
                    <?php endif; ?>


                    <?php if(isset($image_optimizer_upload)): ?>
                    <?php echo $__env->yieldContent('image-optimizer-upload'); ?>

                    <?php endif; ?>

                    <?php if(isset($image_optimizer_download)): ?>
                    <?php echo $__env->yieldContent('image-optimizer-download'); ?>

                    <?php endif; ?>



                <?php if(isset($image_webptopng)): ?>
                    <?php echo $__env->yieldContent('webp-to-png'); ?>
                <?php endif; ?>


                <?php if(isset($image_webptopng_upload)): ?>
                <?php echo $__env->yieldContent('webp-to-png-upload'); ?>
                <?php endif; ?>

                <?php if(isset($image_webptopng_download)): ?>
                <?php echo $__env->yieldContent('webp-to-png-download'); ?>
                <?php endif; ?>





                <?php if(isset($image_webpmaker)): ?>
                    <?php echo $__env->yieldContent('webp-maker'); ?>
                <?php endif; ?>


                <?php if(isset($image_webpmaker_upload)): ?>
                <?php echo $__env->yieldContent('webp-maker-upload'); ?>
                <?php endif; ?>

                <?php if(isset($image_webpmaker_download)): ?>
                <?php echo $__env->yieldContent('webp-maker-download'); ?>
                <?php endif; ?>




                <?php if(isset($image_pngmaker)): ?>
                    <?php echo $__env->yieldContent('png-maker'); ?>
                <?php endif; ?>


                <?php if(isset($image_pngmaker_upload)): ?>
                <?php echo $__env->yieldContent('png-maker-upload'); ?>
                <?php endif; ?>

                <?php if(isset($image_pngmaker_download)): ?>
                <?php echo $__env->yieldContent('png-maker-download'); ?>
                <?php endif; ?>




                <?php if(isset($image_jpgmaker)): ?>
                    <?php echo $__env->yieldContent('jpg-maker'); ?>
                <?php endif; ?>


                <?php if(isset($image_jpgmaker_upload)): ?>
                <?php echo $__env->yieldContent('jpg-maker-upload'); ?>
                <?php endif; ?>

                <?php if(isset($image_jpgmaker_download)): ?>
                <?php echo $__env->yieldContent('jpg-maker-download'); ?>
                <?php endif; ?>





                <?php if(isset($image_webptojpg)): ?>
                    <?php echo $__env->yieldContent('webp-to-jpg'); ?>
                <?php endif; ?>


                <?php if(isset($image_webptojpg_upload)): ?>
                <?php echo $__env->yieldContent('webp-to-jpg-upload'); ?>

                <?php endif; ?>

                <?php if(isset($image_webptojpg_download)): ?>
                <?php echo $__env->yieldContent('webp-to-jpg-download'); ?>

                <?php endif; ?>




                <?php if(isset($image_webptogif)): ?>
                    <?php echo $__env->yieldContent('webp-to-gif'); ?>
                <?php endif; ?>
                <?php if(isset($image_webptogif_upload)): ?>
                <?php echo $__env->yieldContent('webp-to-gif-upload'); ?>
                <?php endif; ?>
                <?php if(isset($image_webptogif_download)): ?>
                <?php echo $__env->yieldContent('webp-to-gif-download'); ?>
                <?php endif; ?>




                <?php if(isset($image_pngtojpg)): ?>
                    <?php echo $__env->yieldContent('png-to-jpg'); ?>
                <?php endif; ?>
                <?php if(isset($image_pngtojpg_upload)): ?>
                <?php echo $__env->yieldContent('png-to-jpg-upload'); ?>
                <?php endif; ?>
                <?php if(isset($image_pngtojpg_download)): ?>
                <?php echo $__env->yieldContent('png-to-jpg-download'); ?>
                <?php endif; ?>



                <?php if(isset($image_pngtogif)): ?>
                    <?php echo $__env->yieldContent('png-to-gif'); ?>
                <?php endif; ?>
                <?php if(isset($image_pngtogif_upload)): ?>
                <?php echo $__env->yieldContent('png-to-gif-upload'); ?>
                <?php endif; ?>
                <?php if(isset($image_pngtogif_download)): ?>
                <?php echo $__env->yieldContent('png-to-gif-download'); ?>
                <?php endif; ?>


                <?php if(isset($image_pngtowebp)): ?>
                <?php echo $__env->yieldContent('png-to-webp'); ?>
            <?php endif; ?>
            <?php if(isset($image_pngtowebp_upload)): ?>
            <?php echo $__env->yieldContent('png-to-webp-upload'); ?>
            <?php endif; ?>
            <?php if(isset($image_pngtowebp_download)): ?>
            <?php echo $__env->yieldContent('png-to-webp-download'); ?>
            <?php endif; ?>




            <?php if(isset($image_jpgtowebp)): ?>
            <?php echo $__env->yieldContent('jpg-to-webp'); ?>
        <?php endif; ?>
        <?php if(isset($image_jpgtowebp_upload)): ?>
        <?php echo $__env->yieldContent('jpg-to-webp-upload'); ?>
        <?php endif; ?>
        <?php if(isset($image_jpgtowebp_download)): ?>
        <?php echo $__env->yieldContent('jpg-to-webp-download'); ?>
        <?php endif; ?>



        <?php if(isset($image_jpgtopng)): ?>
        <?php echo $__env->yieldContent('jpg-to-png'); ?>
    <?php endif; ?>
    <?php if(isset($image_jpgtopng_upload)): ?>
    <?php echo $__env->yieldContent('jpg-to-png-upload'); ?>
    <?php endif; ?>
    <?php if(isset($image_jpgtopng_download)): ?>
    <?php echo $__env->yieldContent('jpg-to-png-download'); ?>
    <?php endif; ?>




    <?php if(isset($image_jpgtogif)): ?>
    <?php echo $__env->yieldContent('jpg-to-gif'); ?>
<?php endif; ?>
<?php if(isset($image_jpgtogif_upload)): ?>
<?php echo $__env->yieldContent('jpg-to-gif-upload'); ?>
<?php endif; ?>
<?php if(isset($image_jpgtogif_download)): ?>
<?php echo $__env->yieldContent('jpg-to-gif-download'); ?>
<?php endif; ?>








                <?php if(isset($image_compressor)): ?>



                <div
                style="





  background-color:#32CD32;
margin:8px 0;

color:white
    "


                >



                    <p style="
                    padding:8px;

                    color:white;
                    margin-bottom:0;
                    ">

                        For permanent links you can use:
                         https://www.imageresizeronline.com/image-compressor?url=https://example.com/source-image.gif


                    </p>





                </div>



                <div
                style="




  padding:8px;

  background-color: #EFEFEE;
margin:8px 0;
    "


                >



                <h1>


                    Image Compressor Online
                </h1>

                    <p

                    style="
                    padding:4px;

                    "
                    >
                        There is no need to install any additional software on your computer to make Simple Image Compressor do its job. You simply browse go to www.imageresizeronline.com/image-compressor and upload the images you want to compress. The file formats supported by Simple Image Compressor include JPEG, PNG , WEBP, GIF and All other image formats.

                    </p>


                    <p  style="
                    padding:4px;

                    ">

                        All you need to do is upload your image file and click "Compress". Then you can download or edit the produced image file.


                    </p>

                </div>

                <?php endif; ?>





                <?php if(isset($index)): ?>



                <div
                style="





  background-color:#32CD32;
margin:8px 0;

color:white
    "


                >



                    <p style="
                    padding:8px;

                    color:white;
                    ">

                        For permanent links you can use: https://www.imageresizeronline.com?url=https://example.com/source-image.gif


                    </p>

                </div>



                <div
                style="




  padding:8px;

  background-color: #EFEFEE;
margin:8px 0;
    "


                >



                <h1>


                    Image Resizer Online
                </h1>

                    <p

                    style="
                    padding:4px;

                    "
                    >
                        There is no need to install any additional software on your computer to make Simple Image Resizer do its job. You simply browse go to www.imageresizeronline.com and upload the images you want to shrink. The file formats supported by Simple Image Resizer include JPEG, JPG, PNG, BMP and GIF and So on.

                    </p>


                    <p  style="
                    padding:4px;

                    ">

                        All you need to do is upload your image file and click "Resize". Then you can download the produced image.

                    </p>

                </div>

                <?php endif; ?>







                <?php if(isset($image_optimizer)): ?>



                <div
                style="





  background-color:#32CD32;
margin:8px 0;

color:white
    "


                >



                    <p style="
                    padding:8px;

                    color:white;
                    ">

                        For permanent links you can use: https://www.imageresizeronline.com?url=https://example.com/source-image.gif


                    </p>

                </div>



                <div
                style="




  padding:8px;

  background-color: #EFEFEE;
margin:8px 0;
    "


                >



                <h1>


                    Image Optimizer Online
                </h1>

                    <p

                    style="
                    padding:4px;

                    "
                    >
                        There is no need to install any additional software on your computer to make Simple Image Optimizer do its job. You simply browse go to www.imageresizeronline.com/image-optimizer and upload the images you want to optimize. The file formats supported by Simple Image Optimizer include JPEG , PNG, WEBP and All other image formats.

                    </p>


                    <p  style="
                    padding:4px;

                    ">

                        All you need to do is upload your WebP file and click "Convert". Then you can download or edit the produced image.


                    </p>

                </div>

                <?php endif; ?>









<div style="
text-align:center;
min-height:220px;


">

    <div class="fb-comments" data-href="http://imageresizeronline.com" data-width="100%" data-numposts="5"></div>

</div>


            </div>

    </main>





</div>










</div>


<div style="padding:32px;

background-color:#222323;

    ">



<div class="container-fluid">

<div class="row">


    <div class="col-sm-3">
        <h1 style="
        color:white;
        ">
           To Resize Image
            </h1>





        <div style="color:white;

        margin-bottom:4px;

        ">

            <a href="/">Image Resizer online</a>
        </div>


        <h1 style="
        color:white;
        ">
           To Optimize Image
            </h1>





        <div style="color:white;
        margin-bottom:4px;
        ">

            <a href="/image-optimizer">Image Optimizer online</a>
        </div>


    </div>

<div class="col-sm-3">


    <h1 style="
    color:white;
    ">
       To Compress Image
        </h1>





    <div style="color:white;

    margin-bottom:4px;

    ">

        <a href="/image-compressor">Image Compressor Online</a>

    </div>

    <div style="color:white;

    margin-bottom:4px;

    ">

        <a href="/image-compressor/under20kb">Image Compressor Under20KB Online</a>

    </div>




    <div style="color:white;

    margin-bottom:4px;

    ">

        <a href="/image-compressor/under30kb">Image Compressor Under30KB Online</a>

    </div>



    <div style="color:white;

    margin-bottom:4px;

    ">

        <a href="/image-compressor/under40kb">Image Compressor Under40KB Online</a>

    </div>



    <div style="color:white;

    margin-bottom:4px;

    ">

        <a href="/image-compressor/under50kb">Image Compressor Under50KB Online</a>

    </div>

    <div style="color:white;

    margin-bottom:4px;

    ">

        <a href="/image-compressor/under60kb">Image Compressor Under60KB Online</a>

    </div>


    <div style="color:white;

    margin-bottom:4px;

    ">

        <a href="/image-compressor/under80kb">Image Compressor Under80KB Online</a>

    </div>



    <div style="color:white;

    margin-bottom:4px;

    ">

        <a href="/image-compressor/under100kb">Image Compressor Under100KB Online</a>

    </div>




    <div style="color:white;

    margin-bottom:4px;

    ">

        <a href="/image-compressor/under150kb">Image Compressor Under150KB Online</a>

    </div>







    <div style="color:white;

    margin-bottom:4px;

    ">

        <a href="/image-compressor/under200kb">Image Compressor Under200KB Online</a>

    </div>



    <div style="color:white;

    margin-bottom:4px;

    ">

        <a href="/image-compressor/under300kb">Image Compressor Under300KB Online</a>

    </div>




    <div style="color:white;

    margin-bottom:4px;

    ">

        <a href="/image-compressor/under500kb">Image Compressor Under500KB Online</a>

    </div>



    <div style="color:white;

    margin-bottom:4px;

    ">

        <a href="/image-compressor/under1mb">Image Compressor Under1MB Online</a>

    </div>

    <div style="color:white;

    margin-bottom:4px;

    ">

        <a href="/image-compressor/under2mb">Image Compressor Under2MB Online</a>

    </div>












</div>

<div class="col-sm-3">
    <h1 style="color: white">JPG<h1>


        <div style="color:white;

        margin-bottom:4px;

        ">

<a href="image-converter/jpg-maker">Make JPG</a>

        </div>


        <div style="color:white;

        margin-bottom:4px;

        ">
        <a href="image-converter/jpg-to-png">JPG to PNG</a>

        </div>


        <div style="color:white;

        margin-bottom:4px;

        ">


<a href="image-converter/jpg-to-webp">JPG to WebP</a>

        </div>
        <div style="color:white;

        margin-bottom:4px;

        ">

<a href="image-converter/jpg-to-gif">JPG to GIF</a>

        </div>






        <h1 style="color: white">PNG<h1>


            <div style="color:white;

            margin-bottom:4px;

            ">

    <a href="image-converter/png-maker">Make PNG</a>

            </div>


            <div style="color:white;

            margin-bottom:4px;

            ">
            <a href="image-converter/png-to-jpg">PNG to JPG</a>

            </div>


            <div style="color:white;

            margin-bottom:4px;

            ">


    <a href="image-converter/png-to-webp">PNG to WebP</a>

            </div>
            <div style="color:white;

            margin-bottom:4px;

            ">

    <a href="image-converter/png-to-gif">PNG to GIF</a>

            </div>


            <h1 style="color: white">WebP<h1>


                <div style="color:white;

                margin-bottom:4px;

                ">

        <a href="image-converter/webp-maker">Make WebP</a>

                </div>


                <div style="color:white;

                margin-bottom:4px;

                ">
                <a href="image-converter/webp-to-png">WebP to PNG</a>

                </div>


                <div style="color:white;

                margin-bottom:4px;

                ">


        <a href="image-converter/webp-to-jpg">WebP to WebP</a>

                </div>
                <div style="color:white;

                margin-bottom:4px;

                ">

        <a href="image-converter/webp-to-gif">WebP to GIF</a>

                </div>




</div>


<div class="col-sm-3">


</div>

</div>
</div>




</div>





    <footer style="padding:32px;

background-color:#222323;

    ">




<h1 style="
color:white;
">
    Image Resizer Online
    </h1>





<div style="color:white;">
Copyright All Rights Reserved @ <?php echo e(date("Y")); ?>


</div>
    </footer>
</div>

</body>
</html>
<?php /**PATH C:\Projects\ImageResizerOnline\resources\views/welcome.blade.php ENDPATH**/ ?>