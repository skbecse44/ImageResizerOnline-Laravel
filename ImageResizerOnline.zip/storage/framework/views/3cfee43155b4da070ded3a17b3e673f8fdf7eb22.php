<?php $__env->startSection('title'); ?>
Image Resizer Online
<?php $__env->stopSection(); ?>


<?php $__env->startSection('image-resizer-upload'); ?>
View one's content
<?php $__env->stopSection(); ?>



<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\ImageResizerOnline\resources\views/index_base.blade.php ENDPATH**/ ?>