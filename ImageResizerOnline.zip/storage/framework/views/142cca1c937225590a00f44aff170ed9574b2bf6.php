<?php $__env->startSection('image-optimizer'); ?>


<?php echo $__env->make('image_optimizer.image_optimizer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('image-optimizer-upload'); ?>

<?php echo $__env->make('image_optimizer.image_optimizer_upload', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('image-optimizer-download'); ?>
<?php echo $__env->make('image_optimizer.image_optimizer_download', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('under20kb'); ?>


<?php echo $__env->make('image_compressor.under20kb.under20kb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('under20kb-upload'); ?>

<?php echo $__env->make('image_compressor.under20kb.under20kb_upload', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('under20kb-download'); ?>
<?php echo $__env->make('image_compressor.under20kb.under20kb_download', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>






<?php $__env->startSection('under30kb'); ?>


<?php echo $__env->make('image_compressor.under30kb.under30kb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('under30kb-upload'); ?>

<?php echo $__env->make('image_compressor.under30kb.under30kb_upload', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('under30kb-download'); ?>
<?php echo $__env->make('image_compressor.under30kb.under30kb_download', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>





<?php $__env->startSection('under50kb'); ?>


<?php echo $__env->make('image_compressor.under50kb.under50kb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('under50kb-upload'); ?>

<?php echo $__env->make('image_compressor.under50kb.under50kb_upload', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('under50kb-download'); ?>
<?php echo $__env->make('image_compressor.under50kb.under50kb_download', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>






<?php $__env->startSection('under60kb'); ?>


<?php echo $__env->make('image_compressor.under60kb.under60kb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('under60kb-upload'); ?>

<?php echo $__env->make('image_compressor.under60kb.under60kb_upload', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('under60kb-download'); ?>
<?php echo $__env->make('image_compressor.under60kb.under60kb_download', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>





<?php $__env->startSection('under80kb'); ?>


<?php echo $__env->make('image_compressor.under80kb.under80kb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('under80kb-upload'); ?>

<?php echo $__env->make('image_compressor.under80kb.under80kb_upload', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




<?php $__env->stopSection(); ?>

<?php $__env->startSection('under80kb-download'); ?>
<?php echo $__env->make('image_compressor.under80kb.under80kb_download', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>







<?php $__env->startSection('under100kb'); ?>


<?php echo $__env->make('image_compressor.under100kb.under100kb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('under100kb-upload'); ?>

<?php echo $__env->make('image_compressor.under100kb.under100kb_upload', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('under100kb-download'); ?>
<?php echo $__env->make('image_compressor.under100kb.under100kb_download', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>




<?php $__env->startSection('under1024kb'); ?>


<?php echo $__env->make('image_compressor.under1024kb.under1024kb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('under1024kb-upload'); ?>

<?php echo $__env->make('image_compressor.under1024kb.under1024kb_upload', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('under1024kb-download'); ?>
<?php echo $__env->make('image_compressor.under1024kb.under1024kb_download', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>





<?php $__env->startSection('under2048kb'); ?>


<?php echo $__env->make('image_compressor.under2048kb.under2048kb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('under2048kb-upload'); ?>

<?php echo $__env->make('image_compressor.under2048kb.under2048kb_upload', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('under2048kb-download'); ?>
<?php echo $__env->make('image_compressor.under2048kb.under2048kb_download', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('under200kb'); ?>

<?php echo $__env->make('image_compressor.under200kb.under200kb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('under200kb-upload'); ?>

<?php echo $__env->make('image_compressor.under200kb.under200kb_upload', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('under200kb-download'); ?>
<?php echo $__env->make('image_compressor.under200kb.under200kb_download', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>




<?php $__env->startSection('under300kb'); ?>

<?php echo $__env->make('image_compressor.under300kb.under300kb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('under300kb-upload'); ?>

<?php echo $__env->make('image_compressor.under300kb.under300kb_upload', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('under300kb-download'); ?>
<?php echo $__env->make('image_compressor.under300kb.under300kb_download', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>




<?php $__env->startSection('under500kb'); ?>

<?php echo $__env->make('image_compressor.under500kb.under500kb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('under500kb-upload'); ?>

<?php echo $__env->make('image_compressor.under500kb.under500kb_upload', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('under500kb-download'); ?>
<?php echo $__env->make('image_compressor.under500kb.under500kb_download', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>





<?php $__env->startSection('under40kb'); ?>

<?php echo $__env->make('image_compressor.under40kb.under40kb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('under40kb-upload'); ?>

<?php echo $__env->make('image_compressor.under40kb.under40kb_upload', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('under40kb-download'); ?>
<?php echo $__env->make('image_compressor.under40kb.under40kb_download', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('under150kb'); ?>

<?php echo $__env->make('image_compressor.under150kb.under150kb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('under150kb-upload'); ?>

<?php echo $__env->make('image_compressor.under150kb.under150kb_upload', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('under150kb-download'); ?>
<?php echo $__env->make('image_compressor.under150kb.under150kb_download', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>











<?php $__env->startSection('image-compressor'); ?>


<?php echo $__env->make('image_compressor.image_compressor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>





<?php $__env->startSection('image-converter'); ?>


<?php echo $__env->make('image_converter.image_converter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('image-compressor-upload'); ?>

<?php echo $__env->make('image_compressor.image_compressor_upload', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('image-compressor-download'); ?>
<?php echo $__env->make('image_compressor.image_compressor_download', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>





<?php $__env->startSection('webp-to-png'); ?>


<?php echo $__env->make('webp.webp_to_png.webp_to_png', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('webp-to-png-upload'); ?>


<?php echo $__env->make('webp.webp_to_png.webp_to_png_upload', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('webp-to-png-download'); ?>
<?php echo $__env->make('webp.webp_to_png.webp_to_png_download', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>




<?php $__env->startSection('webp-maker'); ?>


<?php echo $__env->make('webp.webp_maker.webp_maker', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('webp-maker-upload'); ?>


<?php echo $__env->make('webp.webp_maker.webp_maker_upload', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('webp-maker-download'); ?>
<?php echo $__env->make('webp.webp_maker.webp_maker_download', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>






<?php $__env->startSection('png-maker'); ?>


<?php echo $__env->make('png.png_maker.png_maker', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('png-maker-upload'); ?>


<?php echo $__env->make('png.png_maker.png_maker_upload', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('png-maker-download'); ?>
<?php echo $__env->make('png.png_maker.png_maker_download', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>





<?php $__env->startSection('jpg-maker'); ?>

<?php echo $__env->make('jpg.jpg_maker.jpg_maker', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('jpg-maker-upload'); ?>


<?php echo $__env->make('jpg.jpg_maker.jpg_maker_upload', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('jpg-maker-download'); ?>
<?php echo $__env->make('jpg.jpg_maker.jpg_maker_download', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>









<?php $__env->startSection('webp-to-jpg'); ?>


<?php echo $__env->make('webp.webp_to_jpg.webp_to_jpg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('webp-to-jpg-upload'); ?>


<?php echo $__env->make('webp.webp_to_jpg.webp_to_jpg_upload', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('webp-to-jpg-download'); ?>
<?php echo $__env->make('webp.webp_to_jpg.webp_to_jpg_download', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>







<?php $__env->startSection('webp-to-gif'); ?>


<?php echo $__env->make('webp.webp_to_gif.webp_to_gif', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('webp-to-gif-upload'); ?>


<?php echo $__env->make('webp.webp_to_gif.webp_to_gif_upload', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('webp-to-gif-download'); ?>
<?php echo $__env->make('webp.webp_to_gif.webp_to_gif_download', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>





<?php $__env->startSection('png-to-gif'); ?>


<?php echo $__env->make('png.png_to_gif.png_to_gif', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('png-to-gif-upload'); ?>


<?php echo $__env->make('png.png_to_gif.png_to_gif_upload', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('png-to-gif-download'); ?>
<?php echo $__env->make('png.png_to_gif.png_to_gif_download', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>




<?php $__env->startSection('png-to-jpg'); ?>


<?php echo $__env->make('png.png_to_jpg.png_to_jpg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('png-to-jpg-upload'); ?>


<?php echo $__env->make('png.png_to_jpg.png_to_jpg_upload', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('png-to-jpg-download'); ?>
<?php echo $__env->make('png.png_to_jpg.png_to_jpg_download', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>




<?php $__env->startSection('png-to-webp'); ?>


<?php echo $__env->make('png.png_to_webp.png_to_webp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('png-to-webp-upload'); ?>


<?php echo $__env->make('png.png_to_webp.png_to_webp_upload', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('png-to-webp-download'); ?>
<?php echo $__env->make('png.png_to_webp.png_to_webp_download', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>







<?php $__env->startSection('jpg-to-webp'); ?>


<?php echo $__env->make('jpg.jpg_to_webp.jpg_to_webp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('jpg-to-webp-upload'); ?>


<?php echo $__env->make('jpg.jpg_to_webp.jpg_to_webp_upload', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('jpg-to-webp-download'); ?>
<?php echo $__env->make('jpg.jpg_to_webp.jpg_to_webp_download', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>




<?php $__env->startSection('jpg-to-png'); ?>


<?php echo $__env->make('jpg.jpg_to_png.jpg_to_png', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('jpg-to-png-upload'); ?>


<?php echo $__env->make('jpg.jpg_to_png.jpg_to_png_upload', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('jpg-to-png-download'); ?>
<?php echo $__env->make('jpg.jpg_to_png.jpg_to_png_download', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>







<?php $__env->startSection('jpg-to-gif'); ?>


<?php echo $__env->make('jpg.jpg_to_gif.jpg_to_gif', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('jpg-to-gif-upload'); ?>


<?php echo $__env->make('jpg.jpg_to_gif.jpg_to_gif_upload', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('jpg-to-gif-download'); ?>
<?php echo $__env->make('jpg.jpg_to_gif.jpg_to_gif_download', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('image-resizer'); ?>

    <h1 style="font-weight: 400">Resize Image Online</h1>

    <div style="margin-top: 24px;
background-color: #EFEFEE;
padding:16px 8px;

">

        <div style="padding:8px;
background-color: white;
">


            <div class="tab">
                <button class="tablinks"

                        onclick="openCity(event, 'one')">Upload File</button>
                <button class="tablinks" onclick="openCity(event, 'two')">Paste Image URI or URL</button>
            </div>



            <form method="POST" action="/"

                  enctype="multipart/form-data"
            >

            <?php echo csrf_field(); ?> <!-- <?php echo e(csrf_field()); ?> -->
                <div id="one"

                     style="display: block;
padding-top: 16px;
"
                     class="tabcontent">
                    <h3

                    >Choose Image</h3>

                    <p>Upload image from your computer:
                    </p>

                    <div style="padding:8px 0">

                        <input type="file" name="choose-file">
                    </div>


                </div>

                <div id="two" class="tabcontent">

                    <h3

                    >Choose Image</h3>

                    <p>Paste Image URI or URL


                    </p>

                    <div style="padding:8px 0">

                        <input type="url"
                               name="image-uri"

                               style="padding: 8px"

                               placeholder="https:// or data:"
                        >
                    </div>



                </div>


                <div style="padding:8px">

                    <input
                        type="submit"
                        style="

padding: 8px 16px;
background-color: rebeccapurple;
outline: none;
border: none;
color: white;
border-radius: 6px;
cursor: pointer;
"
                        value="Submit"

                    >
                </div>
                <div class="info-wrapper"
                     style="padding:8px"
                >
                    <p>Supported image types: JPEG, PNG , WEBP, GIF and All other image formats.
                    </p>

                    <p>
                        Max file size: 35MB
                    </p>
                </div>


            </form>









            <script>
                function openCity(evt, cityName) {
                    var i, tabcontent, tablinks;
                    tabcontent = document.getElementsByClassName("tabcontent");
                    for (i = 0; i < tabcontent.length; i++) {
                        tabcontent[i].style.display = "none";
                    }
                    tablinks = document.getElementsByClassName("tablinks");
                    for (i = 0; i < tablinks.length; i++) {
                        tablinks[i].className = tablinks[i].className.replace(" active", "");
                    }
                    document.getElementById(cityName).style.display = "block";
                    evt.currentTarget.className += " active";
                }
            </script>


        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('image-resizer-upload'); ?>

    <style>
        .styled-table {
            border-collapse: collapse;
            margin: 25px 0;
            font-size: 0.9em;
            font-family: sans-serif;
            max-width: 400px;
            width: 100%;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
        }

        .styled-table thead tr {
            background-color: purple;
            color: #fff;
            text-align: left;
        }

        .styled-table th,
        .styled-table td {
            padding: 12px 15px;
        }


        .styled-table tbody tr {
            border-bottom: 1px solid #dddddd;
        }


        .styled-table tbody tr:last-of-type {
            border-bottom: 2px solid purple;
        }

        .resizer-option-disable {
            margin:8px 0;

            padding:8px 16px;
            border:1px solid silver;
            pointer-events: none;
            opacity:0.4;
        }


        .resizer-option-enable{
            margin:8px 0;

            padding:8px 16px;
            border:1px solid silver;
            opacity:1;
        }


    </style>








    <div style="padding: 16px 32px;
				margin:8px 0;
				background-color:white;
				">


        <h1

        style="padding:8px 0"
        >Resize Image Online</h1>

        <div style="text-align: center">




            <?php if(isset($imageUri)): ?>

            <img

style='
max-width:100%;

'
alt="
"
src="<?php echo e($imageUri); ?>"/>


            <?php endif; ?>


        </div>


        <div>



            <table class="styled-table">
                <thead >
                    <tr >
                        <th style="color: white;">File Attributes</th>
                        <th style="color: white;">Info</th>
                    </tr>
                </thead>
                <tbody>



                    <?php if(isset($fileInfo)): ?>

                    <?php if($fileInfo): ?>






                <?php if($fileInfo->width): ?>

                <tr>
                    <td>Height</td>
                    <td><?php echo e($fileInfo->width); ?> PX</td>
                </tr>
                <?php endif; ?>

                <?php if($fileInfo->height): ?>

                <tr>
                    <td>Height</td>
                    <td><?php echo e($fileInfo->height); ?> PX</td>
                </tr>
                <?php endif; ?>

                <?php if($fileInfo->original_size): ?>
                <tr>
                    <td>Original Size</td>
                    <td><?php echo e($fileInfo->original_size); ?></td>
                </tr>
                <?php endif; ?>



                <?php if($fileInfo->f_type): ?>
                <tr>
                    <td>Type</td>
                    <td><?php echo e($fileInfo->f_type); ?></td>
                </tr>
                <?php endif; ?>


                <?php if($fileInfo->f_format): ?>

                <tr>
                    <td>Format</td>
                    <td><?php echo e($fileInfo->f_format); ?></td>
                </tr>

                <?php endif; ?>


                <?php if($fileInfo->mode): ?>
                <tr>
                    <td>Mode</td>
                    <td><?php echo e($fileInfo->mode); ?></td>
                </tr>
                <?php endif; ?>




                <?php endif; ?>



                <?php endif; ?>


                </tbody>
            </table>


        </div>



        <script>




function showVal(val){


document.getElementById('update-perc')
.innerHTML=val;
}




            // Shorthand for $( document ).ready()
            $(function() {




                $( "#set-w-h" ).on( "click", function( event ) {

                    var className = $('#option-one-wrapper').attr('class');

                    if (className==='resizer-option-disable'){
                        $('#method').attr('value',1)

                        $('#option-one-wrapper input').prop('required',true)
                        $('#option-two-wrapper input').prop('required',false)

                        $("#option-one-wrapper").toggleClass('resizer-option-enable resizer-option-disable');
                        $("#option-two-wrapper").toggleClass('resizer-option-disable resizer-option-enable');

                    }



                });


                $( "#range-percentage" ).on( "click", function( event ) {
                    var className = $('#option-two-wrapper').attr('class');

                    if (className==='resizer-option-disable'){
                        $('#method').attr('value',2)

                        $('#option-two-wrapper input').prop('required',true)
                        $('#option-one-wrapper input').prop('required',false)

                        $("#option-one-wrapper").toggleClass('resizer-option-disable resizer-option-enable');
                        $("#option-two-wrapper").toggleClass('resizer-option-enable resizer-option-disable');
                    }



                });

            });

        </script>


    <?php if(isset(
        $formUrl
    )): ?>

    <form



    enctype="multipart/form-data" method="POST"
    action='
    <?php echo e($formUrl); ?>

    '>


    <?php echo csrf_field(); ?>

  <p

  style="padding: 8px 0;

  font-size:24px;
  "
  >Choose the option to resize image</p>


  <div  id="set-w-h"
  >


      <div
          id='option-one-wrapper'


          class="resizer-option-enable"
      >

          <div
          >

              <h3>By setting width and height</h3>

              <div >

                <span style="display:block;

                margin:4px;
                ">


                   Width in PX
                </span>
                  <input type="number"



                         required
                         style="padding:8px;
margin:4px;
"

                         min='1'
                         name='width'/>
              </div>
          </div>


          <div>
              <div>

                <span style="display:block;

                margin:4px;
                ">


                   Height in PX
                </span>
                  <input type="number"
                         min='1'


                         required
                         style="padding:8px;
margin:4px;
"
                         name='height'/>

              </div>
          </div>

      </div>

  </div>

  <div id="range-percentage" >


      <div id ="option-two-wrapper" class="resizer-option-disable">

          <h3>By Percentage </h3>
          <input
              name='resize-perc'

              style='width:inherit'
              type="range"
              max="100"
              min="1"
              value='30'


              oninput="showVal(this.value)" onchange="showVal(this.value)"

          />

          <p>

              Currently the percentage is <span id="update-perc">

                </span>
          </p>



      </div>

  </div>
  <div>




      <div>
          <input
              id='method'
              name='method'
              type='number'
              min='1'
              max='2'
              value='1'
              required
              style='position:absolute;
visibility:hidden;
'
          />


      </div>

      <input
          name='file-uri'
          type='url'
          required
          style='position:absolute;
visibility:hidden;
'
value="<?php echo e($imageUri); ?>"
      />


  </div>
  <button style="padding: 8px 16px;
background-color: purple;
color: white;
font-weight: bold;
border: none;
border-radius:4px;
outline:none;

cursor:pointer;
"

type="submit"
>
      Resize Image !!!
  </button>

</form>
    <?php endif; ?>

    </div>
    </div>

    </div>

<?php $__env->stopSection(); ?>






<?php $__env->startSection('image-resizer-download'); ?>

<style>
    .styled-table {
        border-collapse: collapse;
        margin: 25px 0;
        font-size: 0.9em;
        font-family: sans-serif;
        min-width: 400px;
        box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
    }

    .styled-table thead tr {
        background-color: purple;
        color: #ffffff;
        text-align: left;
    }

    .styled-table th,
    .styled-table td {
        padding: 12px 15px;
    }


    .styled-table tbody tr {
        border-bottom: 1px solid #dddddd;
    }


    .styled-table tbody tr:last-of-type {
        border-bottom: 2px solid purple;
    }




    </style>

    <div style="padding: 16px 32px;
                    margin:8px 0;
                    background-color:white;
                    border-radius:4px;
                    ">

    <div>

    <h1 style='margin-bottom:20px'>Download Resized Image</h1>



    <?php if(isset($savedImageUri)): ?>

    <img
    style='
    max-width:100%;
    display:block;
    height:100%;
    '

    alt=""
    src="<?php echo e($savedImageUri); ?>"/>
    <?php endif; ?>


    </div>


    <div>

    <table class="styled-table">
        <thead>
            <tr>
                <th style="color: white;">File Attributes</th>
                <th style="color: white">Info</th>
            </tr>
        </thead>
        <tbody>


            <?php if(isset($fileInfo)): ?>

            <?php if($fileInfo): ?>






        <?php if($fileInfo->width): ?>

        <tr>
            <td>Height</td>
            <td><?php echo e($fileInfo->width); ?> PX</td>
        </tr>
        <?php endif; ?>

        <?php if($fileInfo->height): ?>

        <tr>
            <td>Height</td>
            <td><?php echo e($fileInfo->height); ?> PX</td>
        </tr>
        <?php endif; ?>

        <?php if($fileInfo->original_size): ?>
        <tr>
            <td>Converted Image Size</td>
            <td><?php echo e($fileInfo->original_size); ?></td>
        </tr>
        <?php endif; ?>



        <?php if($fileInfo->f_type): ?>
        <tr>
            <td>Type</td>
            <td><?php echo e($fileInfo->f_type); ?></td>
        </tr>
        <?php endif; ?>


        <?php if($fileInfo->f_format): ?>

        <tr>
            <td>Format</td>
            <td><?php echo e($fileInfo->f_format); ?></td>
        </tr>

        <?php endif; ?>


        <?php if($fileInfo->mode): ?>
        <tr>
            <td>Mode</td>
            <td><?php echo e($fileInfo->mode); ?></td>
        </tr>
        <?php endif; ?>




        <?php endif; ?>



        <?php endif; ?>


        </tbody>
    </table>






     </div>



    <?php if(isset($savedImageUri)): ?>


    <a href='<?php echo e($savedImageUri); ?>' download>
        <button style="padding: 8px 16px;
        background-color:purple;
        color: white;
        font-weight: bold;
        border: none;
        outline:none;
        border-radius:6px;

    cursor: pointer;
        ">
                                    Download
                                </button>
            </a>
    <?php endif; ?>



    </div>
    </div>










    </div>

    </div>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\ImageResizerOnline\resources\views/index.blade.php ENDPATH**/ ?>