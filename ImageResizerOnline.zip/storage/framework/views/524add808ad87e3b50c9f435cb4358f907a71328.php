<style>
    .styled-table {
        border-collapse: collapse;
        margin: 25px 0;
        font-size: 0.9em;
        font-family: sans-serif;

        box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
    }

    .styled-table thead tr {
        background-color: purple;
        color: #fff;
        text-align: left;
    }

    .styled-table th,
    .styled-table td {
        padding: 12px 15px;
    }


    .styled-table tbody tr {
        border-bottom: 1px solid #dddddd;
    }


    .styled-table tbody tr:last-of-type {
        border-bottom: 2px solid purple;
    }



</style>

<div style="padding: 16px 32px;
            margin:8px 0;
            background-color:white;
            ">


    <h1

    style="padding:8px 0"
    >Download converted Images to WebP</h1>

    <div>





        <?php if(isset($fileInfoItems)): ?>

        <?php if($fileInfoItems): ?>






<div class="container-fluid">


    <div class="row">




        <?php $__currentLoopData = $fileInfoItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fileInfoItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>




    <div class="col-sm-6">


        <div style="padding: 8px;


height:240px;
text-align:center;



        ">
            <img



            style="
            max-width:100%;
            max-height:100%;
position: relative;
            "

            alt="
            "
            src="<?php echo e($fileInfoItem[0]); ?>"/>



        </div>



        <a
download

href="<?php echo e($fileInfoItem[0]); ?>"
>


    <button style="padding: 8px 16px;
background-color: purple;
color: white;
font-weight: bold;
border: none;
border-radius:4px;
outline:none;

cursor:pointer;
"

type="submit"
>
 Download Image
</button>

</a>





        <table class="styled-table">
            <thead >
                <tr >
                    <th style="color: white;">File Attributes</th>
                    <th style="color: white;">Info</th>
                </tr>
            </thead>
            <tbody>




                <?php if($fileInfoItem[1]->width): ?>

                <tr>
                    <td>Width</td>
                    <td><?php echo e($fileInfoItem[1]->width); ?> PX</td>
                </tr>
                <?php endif; ?>

                <?php if($fileInfoItem[1]->height): ?>

                <tr>
                    <td>Height</td>
                    <td><?php echo e($fileInfoItem[1]->height); ?> PX</td>
                </tr>
                <?php endif; ?>

                <?php if($fileInfoItem[1]->original_size): ?>
                <tr>
                    <td>Original Size</td>
                    <td><?php echo e($fileInfoItem[1]->original_size); ?></td>
                </tr>
                <?php endif; ?>



                <?php if($fileInfoItem[1]->f_type): ?>
                <tr>
                    <td>Type</td>
                    <td><?php echo e($fileInfoItem[1]->f_type); ?></td>
                </tr>
                <?php endif; ?>


                <?php if($fileInfoItem[1]->f_format): ?>

                <tr>
                    <td>Format</td>
                    <td><?php echo e($fileInfoItem[1]->f_format); ?></td>
                </tr>

                <?php endif; ?>


                <?php if($fileInfoItem[1]->mode): ?>
                <tr>
                    <td>Mode</td>
                    <td><?php echo e($fileInfoItem[1]->mode); ?></td>
                </tr>
                <?php endif; ?>



            </tbody>
        </table>



    </div>


 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </div>

    </div>


    <?php endif; ?>
    <?php endif; ?>







    </div>



<?php if(isset(
    $downloadUrl
)): ?>




<div>


    <a
    download

    href="<?php echo e($downloadUrl); ?>"
    >


        <button style="padding: 8px 16px;
    background-color: purple;
    color: white;
    font-weight: bold;
    border: none;
    border-radius:4px;
    outline:none;

    cursor:pointer;
    "

    type="submit"
    >
     Download as Zip
    </button>

    </a>

</div>



<?php endif; ?>

</div>
</div>

</div>
<?php /**PATH C:\Projects\ImageResizerOnline\resources\views/webp/webp_maker/webp_maker_download.blade.php ENDPATH**/ ?>